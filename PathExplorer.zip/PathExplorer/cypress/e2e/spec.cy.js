describe('Enter to app web', () => {
  it('passes', () => {
    cy.visit('https://path-explorer-beta.vercel.app/')
  })
})