<p align="center">
  <img src="https://github.com/user-attachments/assets/852eeb60-2b3f-4636-aa86-6c5c9d623dc7" alt="Logo" width="150">
</p>

# PathExplorer

### Stack Tecnológico (contemplado al momento):

![Vite](https://img.shields.io/badge/Vite-646CFF?style=for-the-badge&logo=vite&logoColor=white)
![React](https://img.shields.io/badge/React-61DAFB?style=for-the-badge&logo=react&logoColor=white)
![Supabase](https://img.shields.io/badge/Supabase-3ECF8E?style=for-the-badge&logo=supabase&logoColor=white)
![Vercel](https://img.shields.io/badge/Vercel-000000?style=for-the-badge&logo=vercel&logoColor=white)

Aquí nuestro mockup: [Figma](https://www.figma.com/design/nQ3X7ufUrNWSnpMAhnRLdk/Mockup-Web?node-id=47-669&t=gVNieDOr3b6xSwEw-1)

### Institución:
Tecnológico de Monterrey


### Reto:
PathExplorer


### Materia:
TC3004B.103 Planeación de sistemas de software


## Equipo de desarrollo

| Name | Github | Email |
| --- | --- | --- |
| Marco Antonio Lucio Sosa | [@marcoolucio17](https://github.com/marcoolucio17) | A01285589@tec.mx |
| Juan Eduardo Cibrián Loera | [@xxxx](https://github.com/xxxxx) | A01198418@tec.mx |
| Axel Ariel Grande Ruiz | [@4xlRose](https://github.com/4xlRose) | A01611811@tec.mx |
| Gabriel Ernesto Mujica Proulx |[@xxxx](https://github.com/xxxxx) | A01285409@tec.mx |
| José Emilio Ramírez García | [@xxxx](https://github.com/xxxxx) | A01620903@tec.mx |
| Leonardo Pequeño Moreno | [@xxxx](https://github.com/xxxxx) | A01178029@tec.mx |

### Profesores:
+ Ovidio Cesar Garza Gil
+ Hugo Ernesto Martinez Montenegro
+ Juan Carlos Lavariega Jarquín
+ Jorge Ramón Carranza Velez
+ Roberto Carlos Martínez Moreno

