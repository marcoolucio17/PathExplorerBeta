import React from 'react'

/**
 * Componente Dashboard para usuarios con rol de TFS
 * @returns Void
 */
export const TFSDashboard = () => {
  return (
    <div>TFSDashboard</div>
  )
}
