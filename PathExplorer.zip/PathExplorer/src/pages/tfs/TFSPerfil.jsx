import React from 'react'

export const TFSPerfil = () => {
  return (
    <div>TFSPerfil</div>
  )
}
