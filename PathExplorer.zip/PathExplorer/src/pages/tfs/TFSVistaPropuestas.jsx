import React from 'react'

export const TFSVistaPropuestas = () => {
  return (
    <div>TFSVistaPropuestas</div>
  )
}
