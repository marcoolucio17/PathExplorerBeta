import React from 'react';

import '../../styles/EmpleadoDashboard.css'
import '../../styles/ManagerDashboardCreateProject.css';
import { NavLink } from 'react-router-dom';

export const ManagerDashboardCreateProject = () => { 

    return (
        <div className = "contenedor-Dashboard">
            <p>Hola</p>
        </div>

    )
}

