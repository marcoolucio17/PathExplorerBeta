import React from 'react'

export const ManagerPerfil = () => {
  return (
    <div>ManagerPerfil</div>
  )
}
