import React from 'react'

export const ManagerProyecto = () => {
  return (
    <div>ManagerProyecto</div>
  )
}
