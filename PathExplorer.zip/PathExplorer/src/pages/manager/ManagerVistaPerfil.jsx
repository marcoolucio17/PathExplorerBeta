import React from 'react'

/**
 * 
 * @returns 
 * !!!: este componente es para la vista del manager sobre OTRO perfil
 */
export const ManagerVistaPerfil = () => {
  return (
    <div>ManagerVistaPerfil</div>
  )
}
