import React from "react";
import { EmpleadoHomePage } from "./EmpleadoHomePage/EmpleadoHomePage";

// Re-export the standardized component for backward compatibility
export const EmpleadoHome = () => {
  return <EmpleadoHomePage />;
};

