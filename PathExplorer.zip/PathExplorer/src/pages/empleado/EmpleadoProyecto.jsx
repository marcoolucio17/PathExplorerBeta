// This component now simply re-exports the CSS module version
export { EmpleadoProyectoPage as EmpleadoProyecto } from './EmpleadoProyectoPage/EmpleadoProyectoPage';