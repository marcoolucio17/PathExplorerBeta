// This component now simply re-exports the CSS module version
export { EmpleadoPerfilPage as EmpleadoPerfil } from './EmpleadoPerfilPage/EmpleadoPerfilPage';