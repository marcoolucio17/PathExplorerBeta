import React from 'react'

export const Unauthorized = () => {
  return (
    <div>Ups! No estás autorizado para esta página.</div>
  )
}
